package com.spring.mvc;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ListClass {
	
	@RequestMapping("/showList")
	public ModelAndView addEmpForm(){
		List<String> ls = new ArrayList<String>();
		ls.add("Apple");
		ls.add("Mango");
		ls.add("Papaya");
		ls.add("Kiwi");
		ModelAndView model = new ModelAndView("showList");
		model.addObject("fruitList", ls);
		return model;
	}

}
